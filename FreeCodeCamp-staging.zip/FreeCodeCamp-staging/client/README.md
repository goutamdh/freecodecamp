This is the entry point for the client code.
Code that should run only on the client should be put here.

NOTE(berks): For react specific stuff this should be the entry point
