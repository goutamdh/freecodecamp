#### FreeCodeCamp Issue template
To Use this Template:
* Fill out what you can
* Delete what you do not fill out

NOTE: ISSUES ARE NOT FOR CODE HELP - Ask for Help at https://gitter.im/FreeCodeCamp/Help

#### Issue Description
* When Issue Happens
* Steps To Reproduce

#### Browser Information
* Browser Name, Version
* Operating System

#### Your Code

```js
If relevant, paste all of your challenge code in here
```

#### Screenshot
