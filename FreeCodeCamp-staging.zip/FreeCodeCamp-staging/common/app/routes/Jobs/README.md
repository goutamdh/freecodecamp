This folder contains everything relative to Jobs board
